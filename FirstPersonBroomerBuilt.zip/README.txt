READ ME - First Person Broomer

GOAL: the goal of the game is to reach the end of level 1 and sweep the chicken.

MECHANICS: evade enemies' sights, knock them out by hitting them with your broom or another object.

CONTROLS:
WASD  	move
LMB  	sweep object
P	pause

This build contains a test level. You can acces it through the pause menu. 
You can go back at any time by going through the pause menu once more.

You can watch the gameplay video here:
https://youtu.be/eaW7GbbiZqE